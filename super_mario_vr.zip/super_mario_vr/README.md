# Super Mario VR (WebXR)

Mario model: "Mario obj" by MatiasH290 (https://sketchfab.com/matias029), CC-BY-4.0 (see mario/license.txt). Credit must stay with any distribution.

## Run it
The page must be served over http(s) (glTF/modules don't load from file://).
- PC test: `cd super_mario_vr && python3 -m http.server 8000` → http://localhost:8000 (WASD + drag + Space)
- Quest, USB: `adb reverse tcp:8000 tcp:8000`, then open http://localhost:8000 in Quest Browser → "Enter VR"
- Quest, anywhere: upload the folder to GitHub Pages / Netlify (HTTPS), open it in Quest Browser, "Enter VR".

## Turn it into an APK
Not built here (no Android SDK / internet in my sandbox). Two routes:
1. PWABuilder (pwabuilder.com): host the folder over HTTPS, add a manifest + service worker, then pick the Meta Quest / Android package → APK. Sideload with `adb install game.apk`.
2. Bubblewrap/Capacitor wrapper pointing at your hosted URL.
For a fully offline APK, `npm i three@0.160.0` and copy build/three.module.js + examples/jsm/{loaders/GLTFLoader.js,webxr/VRButton.js,utils/BufferGeometryUtils.js} into the folder, then edit the importmap in index.html to the local paths.

## Controls (Quest)
Left stick walk · right stick snap-turn · A/X/B/Y jump (or really jump) · arms follow controllers.
Head-bump a yellow ? block from below → Super Mushroom (bigger + higher jumps, 20 s) or Star (fast + rainbow glow, 12 s). Touch the item with your head, body or hand.
